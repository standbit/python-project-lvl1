#!/usr/bin/env python3
from brain_games import functions


def main():
    functions.even_check()


if __name__ == '__main__':
    main()
